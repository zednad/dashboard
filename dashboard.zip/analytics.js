// Analytics and calculations module with new card-based filtering
class BankAnalytics {
    constructor(data) {
        this.data = data;
        this.filters = {
            viewMode: 'industry', // 'industry' or 'nab'
            quarter: null
        };
    }
    
    // Set view mode (industry or nab)
    setViewMode(mode) {
        this.filters.viewMode = mode;
        // Clear quarter filter when switching modes unless specifically maintaining it
        return this.getFilteredData();
    }
    
    // Set quarter filter
    setQuarter(quarter) {
        this.filters.quarter = quarter;
        return this.getFilteredData();
    }
    
    // Clear all filters and return to industry view
    clearAllFilters() {
        this.filters = { viewMode: 'industry', quarter: null };
        return this.getFilteredData();
    }
    
    // Get current filter status
    getFilterStatus() {
        const activeFilters = [];
        if (this.filters.viewMode === 'nab') activeFilters.push('NAB View');
        if (this.filters.quarter) activeFilters.push(`Quarter: ${this.filters.quarter}`);
        
        return {
            hasFilters: activeFilters.length > 0 || this.filters.viewMode === 'nab',
            filterText: activeFilters.length > 0 ? activeFilters.join(', ') : 
                       (this.filters.viewMode === 'industry' ? 'Industry Average View' : 'No filters applied'),
            filters: this.filters,
            viewMode: this.filters.viewMode
        };
    }
    
    // Get filtered data based on current filters
    getFilteredData() {
        let filteredData = { ...this.data };
        
        // Apply view mode filter
        if (this.filters.viewMode === 'nab') {
            const banks = ['NAB'];
            filteredData.banks = banks;
            
            // Filter all data structures for NAB only
            const newBankTotals = { NAB: filteredData.bankTotals['NAB'] };
            const newQuarterlyOutages = { NAB: filteredData.quarterlyOutages['NAB'] };
            const newOutageMatrix = { NAB: filteredData.outageMatrix['NAB'] };
            const newServiceOutages = {};
            
            // Recalculate service outages for NAB only
            filteredData.services.forEach(service => {
                newServiceOutages[service] = { NAB: filteredData.serviceOutages[service]['NAB'] };
            });
            
            filteredData.bankTotals = newBankTotals;
            filteredData.quarterlyOutages = newQuarterlyOutages;
            filteredData.serviceOutages = newServiceOutages;
            filteredData.outageMatrix = newOutageMatrix;
        }
        
        // Apply quarter filter
        if (this.filters.quarter) {
            const quarters = [this.filters.quarter];
            filteredData.quarters = quarters;
            
            // Recalculate quarterly data for filtered quarter only
            const newQuarterlyOutages = {};
            filteredData.banks.forEach(bank => {
                newQuarterlyOutages[bank] = {};
                quarters.forEach(quarter => {
                    newQuarterlyOutages[bank][quarter] = filteredData.quarterlyOutages[bank][quarter] || 0;
                });
            });
            filteredData.quarterlyOutages = newQuarterlyOutages;
            
            // Also need to recalculate service outages for the specific quarter
            const newServiceOutages = {};
            filteredData.services.forEach(service => {
                newServiceOutages[service] = {};
                filteredData.banks.forEach(bank => {
                    // Calculate outages for this service and bank in the specific quarter
                    const quarterOutages = filteredData.outageMatrix[bank][service][this.filters.quarter] ? 1 : 0;
                    newServiceOutages[service][bank] = quarterOutages;
                });
            });
            filteredData.serviceOutages = newServiceOutages;
        }
        
        return filteredData;
    }
    
    // Get card metrics for both Industry Average and NAB
    getCardMetrics() {
        const allData = this.data;
        const currentData = this.getFilteredData();
        
        // Industry Average calculations
        const industryTotalOutages = Object.values(allData.bankTotals).reduce((sum, bank) => sum + bank.totalOutages, 0);
        const industryTotalServices = Object.values(allData.bankTotals).reduce((sum, bank) => sum + bank.totalServices, 0);
        const industryRate = (industryTotalOutages / industryTotalServices * 100).toFixed(2);
        
        // NAB calculations  
        const nabTotalOutages = allData.bankTotals['NAB'].totalOutages;
        const nabTotalServices = allData.bankTotals['NAB'].totalServices;
        const nabRate = (nabTotalOutages / nabTotalServices * 100).toFixed(2);
        
        // Current view calculations (for filtered data display)
        let currentTotalOutages = 0;
        if (this.filters.viewMode === 'industry') {
            currentTotalOutages = Object.values(currentData.bankTotals).reduce((sum, bank) => sum + bank.totalOutages, 0);
        } else {
            currentTotalOutages = currentData.bankTotals['NAB'] ? currentData.bankTotals['NAB'].totalOutages : 0;
        }
        
        return {
            industry: {
                rate: `${industryRate}%`,
                totalOutages: industryTotalOutages,
                currentOutages: this.filters.viewMode === 'industry' ? currentTotalOutages : industryTotalOutages
            },
            nab: {
                rate: `${nabRate}%`,
                totalOutages: nabTotalOutages,
                currentOutages: this.filters.viewMode === 'nab' ? currentTotalOutages : nabTotalOutages
            }
        };
    }
    
    // Get data for outage distribution pie chart
    getOutageDistribution() {
        const data = this.getFilteredData();
        const labels = [];
        const values = [];
        const colors = ['#1f77b4', '#ff7f0e', '#d62728', '#2ca02c'];
        
        data.banks.forEach((bank, index) => {
            labels.push(bank);
            values.push(data.bankTotals[bank].totalOutages);
        });
        
        return {
            labels: labels,
            datasets: [{
                data: values,
                backgroundColor: colors.slice(0, labels.length),
                borderColor: '#fff',
                borderWidth: 2
            }]
        };
    }
    
    // Get quarterly comparison data
    getQuarterlyComparison() {
        const data = this.getFilteredData();
        const quarterlyData = {
            labels: this.data.quarters, // Always show all quarters for context
            datasets: []
        };
        
        data.banks.forEach((bank, index) => {
            const colors = {
                ANZ: '#1f77b4',
                Commbank: '#ff7f0e', 
                NAB: '#d62728',
                Westpac: '#2ca02c'
            };
            
            quarterlyData.datasets.push({
                label: bank,
                data: this.data.quarters.map(quarter => this.data.quarterlyOutages[bank][quarter] || 0),
                borderColor: colors[bank],
                backgroundColor: colors[bank] + '20',
                tension: 0.4,
                fill: false,
                pointRadius: 4,
                pointHoverRadius: 6
            });
        });
        
        return quarterlyData;
    }
    
    // Get services bar chart data
    getServicesData() {
        const data = this.getFilteredData();
        const serviceData = {
            labels: data.services,
            datasets: [{
                label: 'Total Outages',
                data: data.services.map(service => {
                    return Object.values(data.serviceOutages[service]).reduce((sum, count) => sum + count, 0);
                }),
                backgroundColor: this.filters.viewMode === 'nab' ? '#d62728' : '#106ebe',
                borderColor: this.filters.viewMode === 'nab' ? '#b71c1c' : '#005a9e',
                borderWidth: 1
            }]
        };
        
        return serviceData;
    }
    
    // Generate insights based on current view
    generateInsights() {
        const data = this.getFilteredData();
        const cardMetrics = this.getCardMetrics();
        const insights = [];
        
        if (this.filters.viewMode === 'industry') {
            // Industry view insights
            insights.push({
                type: 'neutral',
                icon: 'fas fa-chart-bar',
                title: 'Industry Overview',
                content: `Analyzing ${data.banks.length} banks with ${cardMetrics.industry.currentOutages} total outages across all services${this.filters.quarter ? ` in ${this.filters.quarter}` : ''}.`
            });
            
            // Find best and worst performers
            const bankOutages = {};
            data.banks.forEach(bank => {
                bankOutages[bank] = data.bankTotals[bank].totalOutages;
            });
            
            const sortedBanks = Object.keys(bankOutages).sort((a, b) => bankOutages[a] - bankOutages[b]);
            const bestBank = sortedBanks[0];
            const worstBank = sortedBanks[sortedBanks.length - 1];
            
            insights.push({
                type: 'positive',
                icon: 'fas fa-star',
                title: 'Best Performer',
                content: `${bestBank} has the lowest outage count with ${bankOutages[bestBank]} incidents${this.filters.quarter ? ` in ${this.filters.quarter}` : ''}.`
            });
            
            if (sortedBanks.length > 1) {
                insights.push({
                    type: 'negative',
                    icon: 'fas fa-exclamation-triangle',
                    title: 'Needs Attention',
                    content: `${worstBank} has the highest outage count with ${bankOutages[worstBank]} incidents${this.filters.quarter ? ` in ${this.filters.quarter}` : ''}.`
                });
            }
            
        } else {
            // NAB view insights
            insights.push({
                type: 'neutral',
                icon: 'fas fa-bank',
                title: 'NAB Analysis',
                content: `NAB has ${cardMetrics.nab.currentOutages} total outages with a ${cardMetrics.nab.rate} outage rate${this.filters.quarter ? ` in ${this.filters.quarter}` : ''}.`
            });
            
            // Compare NAB to industry average
            const nabRate = parseFloat(cardMetrics.nab.rate);
            const industryRate = parseFloat(cardMetrics.industry.rate);
            
            if (nabRate < industryRate) {
                insights.push({
                    type: 'positive',
                    icon: 'fas fa-thumbs-up',
                    title: 'Above Average Performance',
                    content: `NAB's ${nabRate}% outage rate is ${(industryRate - nabRate).toFixed(2)}% below the industry average of ${industryRate}%.`
                });
            } else {
                insights.push({
                    type: 'negative',
                    icon: 'fas fa-trending-up',
                    title: 'Below Average Performance',
                    content: `NAB's ${nabRate}% outage rate is ${(nabRate - industryRate).toFixed(2)}% above the industry average of ${industryRate}%.`
                });
            }
        }
        
        // Service analysis
        const serviceStats = {};
        data.services.forEach(service => {
            serviceStats[service] = Object.values(data.serviceOutages[service]).reduce((sum, count) => sum + count, 0);
        });
        
        if (Object.keys(serviceStats).length > 0) {
            const worstService = Object.keys(serviceStats).reduce((a, b) => serviceStats[a] > serviceStats[b] ? a : b);
            const bestService = Object.keys(serviceStats).reduce((a, b) => serviceStats[a] < serviceStats[b] ? a : b);
            
            insights.push({
                type: 'neutral',
                icon: 'fas fa-cogs',
                title: 'Service Analysis',
                content: `${worstService} had the most outages (${serviceStats[worstService]}) while ${bestService} had the fewest (${serviceStats[bestService]})${this.filters.quarter ? ` in ${this.filters.quarter}` : ''}.`
            });
        }
        
        return insights;
    }
}

// Initialize analytics
window.analytics = new BankAnalytics(window.bankData); 