// Chart.js visualization functions with new interactive filtering system
class ChartManager {
    constructor() {
        this.charts = {};
        this.defaultOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        padding: 15,
                        font: {
                            size: 10,
                            weight: '500'
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: 'white',
                    bodyColor: 'white',
                    borderColor: 'rgba(255, 255, 255, 0.2)',
                    borderWidth: 1,
                    cornerRadius: 6,
                    padding: 8,
                    titleFont: { size: 10 },
                    bodyFont: { size: 9 }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#666',
                        font: {
                            size: 9
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#666',
                        font: {
                            size: 9
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                }
            }
        };
    }
    
    // Create outage distribution pie chart
    createOutageDistributionChart() {
        const ctx = document.getElementById('outageDistributionChart').getContext('2d');
        const data = window.analytics.getOutageDistribution();
        
        if (this.charts.outageDistribution) {
            this.charts.outageDistribution.destroy();
        }
        
        this.charts.outageDistribution = new Chart(ctx, {
            type: 'doughnut',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 10,
                            font: {
                                size: 9,
                                weight: '500'
                            }
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: 'white',
                        bodyColor: 'white',
                        borderColor: 'rgba(255, 255, 255, 0.2)',
                        borderWidth: 1,
                        cornerRadius: 6,
                        padding: 8,
                        titleFont: { size: 10 },
                        bodyFont: { size: 9 },
                        callbacks: {
                            label: function(context) {
                                const percentage = ((context.parsed / context.dataset.data.reduce((a, b) => a + b, 0)) * 100).toFixed(1);
                                return `${context.label}: ${context.parsed} outages (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }
    
    // Create quarterly comparison chart with click handlers
    createQuarterlyChart() {
        const ctx = document.getElementById('quarterlyChart').getContext('2d');
        const data = window.analytics.getQuarterlyComparison();
        
        if (this.charts.quarterly) {
            this.charts.quarterly.destroy();
        }
        
        this.charts.quarterly = new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                ...this.defaultOptions,
                onClick: (event, elements) => {
                    if (elements.length > 0) {
                        const dataIndex = elements[0].index;
                        const quarter = data.labels[dataIndex];
                        
                        // Toggle quarter filter
                        if (window.analytics.filters.quarter === quarter) {
                            window.analytics.setQuarter(null);
                        } else {
                            window.analytics.setQuarter(quarter);
                        }
                        window.dashboardManager.updateAllData();
                    }
                },
                plugins: {
                    ...this.defaultOptions.plugins,
                    tooltip: {
                        ...this.defaultOptions.plugins.tooltip,
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${context.parsed.y} outages`;
                            },
                            afterLabel: function() {
                                return 'Click to filter by quarter';
                            }
                        }
                    }
                },
                scales: {
                    ...this.defaultOptions.scales,
                    y: {
                        ...this.defaultOptions.scales.y,
                        title: {
                            display: true,
                            text: 'Outages',
                            color: '#666',
                            font: {
                                size: 10,
                                weight: '600'
                            }
                        }
                    },
                    x: {
                        ...this.defaultOptions.scales.x,
                        title: {
                            display: true,
                            text: 'Quarter',
                            color: '#666',
                            font: {
                                size: 10,
                                weight: '600'
                            }
                        }
                    }
                }
            }
        });
        
        // Highlight selected quarter
        if (window.analytics.filters.quarter) {
            const quarterIndex = data.labels.indexOf(window.analytics.filters.quarter);
            if (quarterIndex !== -1) {
                // Add visual indication for selected quarter (could be enhanced with styling)
                this.charts.quarterly.options.scales.x.ticks.callback = function(value, index) {
                    const label = this.getLabelForValue(value);
                    return index === quarterIndex ? `► ${label}` : label;
                };
                this.charts.quarterly.update();
            }
        }
    }
    
    // Create services bar chart
    createServicesChart() {
        const ctx = document.getElementById('servicesChart').getContext('2d');
        const data = window.analytics.getServicesData();
        
        if (this.charts.services) {
            this.charts.services.destroy();
        }
        
        this.charts.services = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                ...this.defaultOptions,
                plugins: {
                    ...this.defaultOptions.plugins,
                    legend: {
                        display: false
                    },
                    tooltip: {
                        ...this.defaultOptions.plugins.tooltip,
                        callbacks: {
                            label: function(context) {
                                return `${context.parsed.y} outages`;
                            }
                        }
                    }
                },
                scales: {
                    ...this.defaultOptions.scales,
                    y: {
                        ...this.defaultOptions.scales.y,
                        title: {
                            display: true,
                            text: 'Total Outages',
                            color: '#666',
                            font: {
                                size: 10,
                                weight: '600'
                            }
                        }
                    },
                    x: {
                        ...this.defaultOptions.scales.x,
                        title: {
                            display: true,
                            text: 'Payment Services',
                            color: '#666',
                            font: {
                                size: 10,
                                weight: '600'
                            }
                        },
                        ticks: {
                            maxRotation: 45,
                            minRotation: 45
                        }
                    }
                }
            }
        });
    }
    
    // Update all charts
    updateAllCharts() {
        this.createOutageDistributionChart();
        this.createQuarterlyChart();
        this.createServicesChart();
    }
    
    // Destroy all charts
    destroyAllCharts() {
        Object.values(this.charts).forEach(chart => {
            if (chart && typeof chart.destroy === 'function') {
                chart.destroy();
            }
        });
        this.charts = {};
    }
}

// Initialize chart manager
window.chartManager = new ChartManager(); 