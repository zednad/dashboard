// Main dashboard initialization and UI management with new card system
class DashboardManager {
    constructor() {
        this.isInitialized = false;
        this.filterElements = {};
    }
    
    // Initialize the dashboard
    init() {
        if (this.isInitialized) return;
        
        try {
            // Wait for all dependencies to load
            if (typeof window.bankData === 'undefined' || 
                typeof window.analytics === 'undefined' || 
                typeof window.chartManager === 'undefined') {
                setTimeout(() => this.init(), 100);
                return;
            }
            
            this.initializeFilterElements();
            this.setupEventListeners();
            this.updateAllData();
            this.updateTimestamp();
            this.addAnimations();
            
            this.isInitialized = true;
            console.log('Dashboard initialized successfully');
            
        } catch (error) {
            console.error('Dashboard initialization failed:', error);
            this.showError('Failed to initialize dashboard. Please refresh the page.');
        }
    }
    
    // Initialize filter UI elements
    initializeFilterElements() {
        this.filterElements = {
            indicator: document.getElementById('filterIndicator'),
            text: document.getElementById('filterText'),
            clearButton: document.getElementById('clearFilters'),
            industryCard: document.getElementById('industryCard'),
            nabCard: document.getElementById('nabCard')
        };
    }
    
    // Setup event listeners for interactive elements
    setupEventListeners() {
        // Clear filters button
        if (this.filterElements.clearButton) {
            this.filterElements.clearButton.addEventListener('click', () => {
                this.clearAllFilters();
            });
        }
        
        // Industry Average card click handler
        if (this.filterElements.industryCard) {
            this.filterElements.industryCard.addEventListener('click', () => {
                this.setViewMode('industry');
            });
        }
        
        // NAB card click handler
        if (this.filterElements.nabCard) {
            this.filterElements.nabCard.addEventListener('click', () => {
                this.setViewMode('nab');
            });
        }
    }
    
    // Set view mode (industry or nab)
    setViewMode(mode) {
        window.analytics.setViewMode(mode);
        this.updateAllData();
    }
    
    // Clear all filters
    clearAllFilters() {
        window.analytics.clearAllFilters();
        this.updateAllData();
    }
    
    // Update all data and UI
    updateAllData() {
        this.updateFilterUI();
        this.updateCardMetrics();
        this.updateCharts();
        this.updateInsights();
    }
    
    // Update filter UI indicators
    updateFilterUI() {
        const filterStatus = window.analytics.getFilterStatus();
        
        // Update filter indicator
        if (this.filterElements.indicator) {
            if (filterStatus.hasFilters) {
                this.filterElements.indicator.classList.add('active');
            } else {
                this.filterElements.indicator.classList.remove('active');
            }
        }
        
        if (this.filterElements.text) {
            this.filterElements.text.textContent = filterStatus.filterText;
        }
        
        // Update clear filters button
        if (this.filterElements.clearButton) {
            if (filterStatus.hasFilters) {
                this.filterElements.clearButton.classList.add('active');
            } else {
                this.filterElements.clearButton.classList.remove('active');
            }
        }
        
        // Update card selection states
        this.updateCardSelection(filterStatus.viewMode);
    }
    
    // Update card visual selection
    updateCardSelection(viewMode) {
        // Clear all selections
        if (this.filterElements.industryCard) {
            this.filterElements.industryCard.classList.remove('selected');
        }
        if (this.filterElements.nabCard) {
            this.filterElements.nabCard.classList.remove('selected');
        }
        
        // Set current selection
        if (viewMode === 'industry' && this.filterElements.industryCard) {
            this.filterElements.industryCard.classList.add('selected');
        } else if (viewMode === 'nab' && this.filterElements.nabCard) {
            this.filterElements.nabCard.classList.add('selected');
        }
    }
    
    // Update card metrics
    updateCardMetrics() {
        try {
            const metrics = window.analytics.getCardMetrics();
            
            // Update Industry Average card
            const industryRateEl = document.getElementById('industry-outage-rate');
            const industryOutagesEl = document.getElementById('industry-total-outages');
            
            if (industryRateEl) {
                industryRateEl.textContent = metrics.industry.rate;
            }
            if (industryOutagesEl) {
                industryOutagesEl.textContent = `${metrics.industry.currentOutages} total outages`;
            }
            
            // Update NAB card
            const nabRateEl = document.getElementById('nab-outage-rate');
            const nabOutagesEl = document.getElementById('nab-total-outages');
            
            if (nabRateEl) {
                nabRateEl.textContent = metrics.nab.rate;
            }
            if (nabOutagesEl) {
                nabOutagesEl.textContent = `${metrics.nab.currentOutages} total outages`;
            }
            
        } catch (error) {
            console.error('Error updating card metrics:', error);
        }
    }
    
    // Update all charts
    updateCharts() {
        try {
            window.chartManager.updateAllCharts();
        } catch (error) {
            console.error('Error updating charts:', error);
        }
    }
    
    // Update insights section
    updateInsights() {
        try {
            const insights = window.analytics.generateInsights();
            const container = document.getElementById('insightsContainer');
            
            if (!container) {
                console.error('Insights container not found');
                return;
            }
            
            container.innerHTML = '';
            
            insights.forEach((insight, index) => {
                const card = document.createElement('div');
                card.className = `insight-card insight-${insight.type}`;
                
                card.innerHTML = `
                    <h3><i class="${insight.icon}"></i> ${insight.title}</h3>
                    <p>${insight.content}</p>
                `;
                
                container.appendChild(card);
            });
            
        } catch (error) {
            console.error('Error updating insights:', error);
        }
    }
    
    // Add animations to elements
    addAnimations() {
        // Add fade-in animation to metric cards
        const metricCards = document.querySelectorAll('.metric-card');
        metricCards.forEach((card, index) => {
            card.classList.add('fade-in');
            card.style.animationDelay = `${index * 0.1}s`;
        });
        
        // Add fade-in animation to chart containers
        const chartContainers = document.querySelectorAll('.chart-container');
        chartContainers.forEach((container, index) => {
            container.classList.add('fade-in');
            container.style.animationDelay = `${0.5 + index * 0.1}s`;
        });
    }
    
    // Update timestamp
    updateTimestamp() {
        const timestampElement = document.getElementById('timestamp');
        if (timestampElement) {
            const now = new Date();
            timestampElement.textContent = now.toLocaleString();
        }
    }
    
    // Show error message
    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #e74c3c;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            z-index: 1000;
            max-width: 300px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            font-size: 0.8rem;
        `;
        errorDiv.textContent = message;
        
        document.body.appendChild(errorDiv);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (errorDiv.parentNode) {
                errorDiv.parentNode.removeChild(errorDiv);
            }
        }, 5000);
    }
    
    // Refresh dashboard data
    refresh() {
        this.isInitialized = false;
        window.chartManager.destroyAllCharts();
        window.analytics.clearAllFilters();
        this.init();
    }
    
    // Handle window resize
    handleResize() {
        if (this.isInitialized) {
            setTimeout(() => {
                window.chartManager.updateAllCharts();
            }, 250);
        }
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Create dashboard manager instance
    window.dashboardManager = new DashboardManager();
    
    // Initialize dashboard
    window.dashboardManager.init();
    
    // Handle window resize
    let resizeTimeout;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(() => {
            window.dashboardManager.handleResize();
        }, 250);
    });
});

// Handle errors globally
window.addEventListener('error', function(event) {
    console.error('Global error:', event.error);
    if (window.dashboardManager) {
        window.dashboardManager.showError('An error occurred. Some features may not work correctly.');
    }
});

// Prevent console errors from crashing the dashboard
window.addEventListener('unhandledrejection', function(event) {
    console.error('Unhandled promise rejection:', event.reason);
    event.preventDefault();
}); 